1. 将作业代码解压

2. 补充完整代码，并编译运行：

   ```c++
   cd nullspace_test // 切换到代码路径下
   mkdir build
   cd build
   cmake ..
   make              // 编译
   ./NullSpaceTest   //运行程序
   ```

   
